function noise_robust_RLSF
J = imread(['dataset/' 'gaussian_0.0104.bmp']);
if size(J,3)==3
    J_t=J;
    J=J(:,:,1);
end
%% obtained groundtruth
mask = imread('dataset/bw.bmp');
mask = logical(mask);
%% add Gaussian noise with 
% J = imnoise(J,'gaussian',0,0.01);

%% initialize mask
mask_init = logical(imread('mask2.bmp'));

%% run RLSF
tic
seg1 = LSM_TEST(double(J),mask_init);
toc

J1 = colorfinalresult(seg1,J);
imshow(J1);
