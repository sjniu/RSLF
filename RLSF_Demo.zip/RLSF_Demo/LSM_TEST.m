function seg = LSM_TEST(Img,mask_init)
epsilon = 0.6;%0.1
num_it =1000;%round(0.1*sum(mask(:)));1000
rad = 10;
alpha = 0.02;% coefficient of the length term 0.01
% mask_init = zeros(size(Img(:,:,1)));
% mask_init(75:130,80:120) = 1;%1040
% mask_init(mask(:)==0) = 0;
seg = RLSF(Img,mask_init,rad,alpha,num_it,epsilon);
% seg = local_AC_UM(Img,mask_init,rad,alpha,num_it,epsilon);

